#ifndef PRIME_H
#define PRIME_H

char* arrayInit (int N);
void changeMultiples (char* array, int arrayLen, int value);
int isPrime (char value);
void freeArray (char *array);
void showPrime (char* array, int arrayLen);

#endif