#ifndef PRIME_H
#define PRIME_H

int* arrayInit (int N);
void changeMultiples (int* array, int arrayLen, int value);
int isPrime (int value);
void freeArray (int *array);


#endif